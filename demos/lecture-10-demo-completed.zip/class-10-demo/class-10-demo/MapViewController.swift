//
//  ViewController.swift
//  class-10-demo
//
//  Created by Misty Liao on 11/15/21.
//

import Firebase
import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    var ref: DatabaseReference!
    var refHandle: DatabaseHandle!
    
    @IBOutlet var coordinateLabel: UILabel!
    @IBOutlet var mapView: MKMapView!
    
    let towneBuildingCoordinate = CLLocationCoordinate2D(latitude: 39.951870, longitude: -75.190350)
    
    let locationManager = CLLocationManager()
    var currentLocation: CLLocation?

    override func viewDidLoad() {
        mapView.delegate = self
        super.viewDidLoad()
        ref = Database.database().reference()
        refHandle = ref.observe(DataEventType.value, with: {
            (snapshot) in
            if let value = snapshot.value as? NSDictionary, let initalData = value["initalData"] as? NSDictionary, let coordinate = initalData["coordinate"] as? String {
                DispatchQueue.main.async {
                    self.coordinateLabel.text = "Data has changed: \(coordinate)"
                }
            } else {
                DispatchQueue.main.async {
                    self.coordinateLabel.text = "Data is null"
                }
            }
        })
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        locationManager.requestAlwaysAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    @IBAction func writeData() {
        if let location = currentLocation {
            self.ref.child("initalData").setValue(["coordinate":"\(location.coordinate.latitude), \(location.coordinate.longitude)"])
        } else {
            print("Failed to write data")
        }
    }
    
    @IBAction func removeData() {
        self.ref.child("initalData").setValue(nil)
    }
    
    @IBAction func centerMapAtUserLocation() {
        // center and a region
        currentLocation = locationManager.location
        let regionRadius: CLLocationDistance = 2000
        if let location = currentLocation {
            let center = location.coordinate
            let region = MKCoordinateRegion(center: center, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
            mapView.setRegion(region, animated: true)
        } else {
            print("Failed to center location.")
        }
    }
    
    @IBAction func addMapAnnotation() {
        let coordinate = currentLocation?.coordinate
        let annotation = MKPointAnnotation()
        if let coord = coordinate {
            annotation.coordinate = coord
            mapView.addAnnotation(annotation)
            coordinateLabel.text = "\(coord.latitude), \(coord.longitude)"
        } else {
            print("Failed to add annotation")
        }
    }
    
    @IBAction func addMapOverlay() {
        let coordinate = currentLocation?.coordinate
        if let coord = coordinate {
            let routeLine = MKPolyline(coordinates: [coord, towneBuildingCoordinate], count: 2)
            mapView.addOverlay(routeLine)
        } else {
            print("Failed to add overlay.")
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        // custom renderer
        let renderer = MKPolylineRenderer(overlay: overlay)

        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 5
        
        return renderer
    }

}

