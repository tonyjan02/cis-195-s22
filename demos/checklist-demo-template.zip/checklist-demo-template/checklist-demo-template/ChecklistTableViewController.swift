//
//  ViewController.swift
//  checklist-demo-template
//
//  Created by Misty Liao on 10/11/21.
//

import UIKit

class ChecklistTableViewController: UITableViewController {

    // TODO: Initialize data source
    
    // MARK: Load test data
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Implement basic table view methods (delegate and data source)
    override func numberOfSections(in tableView: UITableView) -> Int {
        // TODO: implement
        return 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // TODO: implement
        return 0
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection
                                section: Int) -> String? {
        // TODO: implement
        return ""
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // TODO: Set reusable cell identifier for dequeueing, update row using index path information and data source
        return UITableViewCell()
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // TODO: implement
        return 0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // MARK: Make sure rows do not stay selected when interacted with
    }

}

// MARK: Setup Checklist model here (MVC); individual tasks AND groups of tasks

