//
//  ChecklistTableViewCell.swift
//  checklist-demo-template
//
//  Created by Misty Liao on 10/11/21.
//

import Foundation
import UIKit

class ChecklistTableViewCell: UITableViewCell {
    // MARK: Insert Table View Cell properties and outlets here
}
