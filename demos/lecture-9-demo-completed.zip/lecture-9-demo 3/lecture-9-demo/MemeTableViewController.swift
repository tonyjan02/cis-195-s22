//
//  ViewController.swift
//  lecture-9-demo
//
//  Created by Misty Liao on 3/21/22.
//

// relevant links:
// KINGFISHER PACKAGE - https://github.com/onevcat/Kingfisher.git
// MEME API - https://api.imgflip.com/get_memes

import UIKit
import Kingfisher

class MemeTableViewController: UITableViewController {

    var memeData = [Meme]()
    
    override func viewDidLoad() {
        getData()
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // TODO: retrieve meme data
    func getData() {
        // TODO: setup valid URL endpoint
        guard let memeURL = URL(string: "https://api.imgflip.com/get_memes") else {
            fatalError("URL was invalid")
        }
        
        // TODO: use URL data task to retrieve data and decode
        let task = URLSession.shared.dataTask(with: memeURL) { data, response, error in
            if error == nil, let data = data {
                if let decodedMemes = try? JSONDecoder().decode(MemeCollection.self, from: data) {
                    self.memeData = decodedMemes.data.memes
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
            }
        }
        
        // TODO: resume task
        task.resume()
    }
    
    // TODO: update
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memeData.count
    }
    
    // TODO: update
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90.0
    }
    
    // TODO: update
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MemeCell") else {
            fatalError("Failed to dequeue")
        }
        
        if let nameLabel = cell.viewWithTag(1) as? UILabel {
            nameLabel.text = memeData[indexPath.row].name
        }
        if let idLabel = cell.viewWithTag(2) as? UILabel {
            idLabel.text = memeData[indexPath.row].id
        }
        if let memeImage = cell.viewWithTag(3) as? UIImageView {
            memeImage.kf.setImage(with: memeData[indexPath.row].imageURL)
        }
        return cell
    }

}

// TODO: set up data model for decoding
struct Meme: Codable {
    let id: String
    let name: String
    let imageURL: URL
    
    enum CodingKeys: String, CodingKey {
        case imageURL = "url"
        case id, name
    }
}

struct MemeCollection: Codable {
    let data: Data
    
    struct Data: Codable {
        let memes: [Meme]
    }
}

