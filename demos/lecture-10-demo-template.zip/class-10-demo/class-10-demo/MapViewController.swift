//
//  ViewController.swift
//  class-10-demo
//
//  Created by Misty Liao on 11/15/21.
//

// add Firebase packages and import
import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet var coordinateLabel: UILabel!
    @IBOutlet var mapView: MKMapView!
    
    let towneBuildingCoordinates = CLLocationCoordinate2D(latitude: 39.951870, longitude: -75.190350)
    
    // create a location manager for tracking user location
    // store variable for current location

    override func viewDidLoad() {
        super.viewDidLoad()
        // TODO: setup map view and Firebase Database reference
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // TODO: request location access and start updating
        // TODO: add to info p.list authorization for purpose strings
    }
    
    @IBAction func writeData() {
        // TODO: update Firebase with the current location
    }
    
    @IBAction func removeData() {
        // TODO: set current location data in Firebase to nil (remove)
    }
    
    @IBAction func centerMapAtUserLocation() {
        // TODO: get the current location
        // TODO: set the region of the map view with a given radius
    }
    
    @IBAction func addMapAnnotation() {
        // TODO: create and add an MKPointAnnotation with the current location to the Map View
        // TODO: update text label with the coordinates
    }
    
    @IBAction func addMapOverlay() {
        // TODO: create a MKPolyline connecting our location to Towne
        // TODO: add the overlay to Map View
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        // custom renderer
        let renderer = MKPolylineRenderer(overlay: overlay)

        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 5
        
        return renderer
    }

}

