//
//  ViewController.swift
//  checklist-demo-template
//
//  Created by Misty Liao on 10/11/21.
//

import UIKit

class ChecklistTableViewController: UITableViewController {

    var checklistDataSource: [ChecklistGroup] = [ChecklistGroup]()
    
    // MARK: Load test data
    override func viewDidLoad() {
        checklistDataSource.append(ChecklistGroup(name: "Homework", taskList: [ChecklistItem(name: "Do CIS 195 assignment"), ChecklistItem(name: "Finish Quad Tree"), ChecklistItem(name: "Draft ASAM paper")]))
        checklistDataSource.append(ChecklistGroup(name: "Errands", taskList: [ChecklistItem(name: "Do laundry"), ChecklistItem(name: "Take out the trash")]))
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Implement basic table view methods (delegate and data source)
    override func numberOfSections(in tableView: UITableView) -> Int {
        return checklistDataSource.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return checklistDataSource[section].taskList.count
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection
                                section: Int) -> String? {
        return checklistDataSource[section].name
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // dequeue a reusable cell with the proper identifier
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ChecklistCellIdentifier") as? ChecklistTableViewCell else {
            fatalError("Failed to dequeue.")
        }
        
        cell.checklistItem = checklistDataSource[indexPath.section].taskList[indexPath.row]
        
        // access the tableviewcell elements and update them with the correct data based on the index path
        cell.taskLabel.text = checklistDataSource[indexPath.section].taskList[indexPath.row].taskName
        
        if checklistDataSource[indexPath.section].taskList[indexPath.row].isChecked {
            cell.checklistButton.setImage(UIImage(named: "check-box"), for: .normal)
        } else {
            cell.checklistButton.setImage(UIImage(named: "blank-check-box"), for: .normal)
        }

        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // MARK: Make sure rows do not stay selected when interacted with
        tableView.deselectRow(at: indexPath, animated: true)
    }

}

// MARK: Setup Checklist model here (MVC); individual tasks AND groups of tasks

struct ChecklistItem {
    var taskName: String
    var isChecked: Bool
    
    init(name: String) {
        self.taskName = name
        self.isChecked = false
    }
}

struct ChecklistGroup {
    var name: String
    var taskList: [ChecklistItem]
    
    init(name: String, taskList: [ChecklistItem]){
        self.name = name
        self.taskList = taskList
    }
}

