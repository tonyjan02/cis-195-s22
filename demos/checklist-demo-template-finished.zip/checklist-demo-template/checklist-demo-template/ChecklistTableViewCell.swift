//
//  ChecklistTableViewCell.swift
//  checklist-demo-template
//
//  Created by Misty Liao on 10/11/21.
//

import Foundation
import UIKit

class ChecklistTableViewCell: UITableViewCell {
    
    @IBOutlet var taskLabel: UILabel!
    @IBOutlet var checklistButton: UIButton!
    
    // checklist item
    var checklistItem: ChecklistItem?
    
    // run when the user checks an item off
    @IBAction func checklistPressed(_ sender: UIButton) {
        if let currentItem = checklistItem {
            if currentItem.isChecked {
                checklistButton.setImage(UIImage(named: "blank-check-box"), for: .normal)
                checklistItem?.isChecked = false
            } else {
                checklistButton.setImage(UIImage(named: "check-box"), for: .normal)
                checklistItem?.isChecked = true
            }
        }
    }
    // MARK: Insert Table View Cell properties and outlets here
}
