//
//  ViewController.swift
//  lecture-9-demo
//
//  Created by Misty Liao on 3/21/22.
//

// relevant links:
// KINGFISHER PACKAGE - https://github.com/onevcat/Kingfisher.git
// MEME API - https://api.imgflip.com/get_memes

import UIKit
// import any third party packages here

class MemeTableViewController: UITableViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // TODO: retrieve meme data
    func getData() {
        // TODO: setup valid URL endpoint
        
        // TODO: use URL data task to retrieve data and decode
        
        // TODO: resume task
    }
    
    // TODO: update
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    // TODO: update
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 1
    }
    
    // TODO: update
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }

}

// TODO: set up data model for decoding
struct Meme: Codable {
    
}

