//
//  ViewController.swift
//  lecture-6-demo
//
//  Created by Misty Liao on 2/21/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var setTextButton: UIButton!
    @IBOutlet var messageLabel: UILabel!
    @IBOutlet var inputTextBox: UITextView!

    override func viewDidLoad() {
        messageLabel.text = ""
        inputTextBox.text = ""
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func setText(_ sender: UIButton) {
        if let currText = inputTextBox.text {
            messageLabel.text = currText
            print("success")
        } else {
            messageLabel.text = "No text inputted."
            print("failure")
        }
    }


}

